from django.contrib import admin
from .models import Especialista

admin.site.register(Especialista)
